/*
 * The MIT License
 *
 * Copyright 2021 CmdrZin.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sub-license, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * Project: HC-SR04_1
 *
 * Created: 1/7/2021 4:29:04 PM
 * Author : Cmdrzin
 */ 
#define F_CPU	10000000	// Definition needed for delay.h functions. Needs to be before #include.

#include <avr/io.h>			// require for any AVR project.
#include <util/delay.h>		// needed for _delay_us().

// These definitions will differ based on the processor used.
#define HC_DIR		PORTB_DIR	// DDR register.
#define	HC_PORT		PORTB_OUT	// Port for output pin connected to the HC-SR04.
#define TRIG		PIN3_bm		// TRIG input to HC-SR04 sensor.
#define	HC_PIN		PORTB_IN	// Port for input pin connected to the HC-SR04.
#define ECHO		PIN2_bm		// ECHO output of the HC-SR04 sensor.

#define LED_DIR		PORTF_DIR
#define LED_PORT	PORTF_OUT	// I/O Port for output to on-board LED.
#define LED			PIN5_bm		// LED drive pin.


/*
 * Simple trigger and wait loop.
 */
int main(void)
{
	uint16_t time;
			
	// Configure the Main Clock Prescaler for div by 2.
	CPU_CCP = CCP_IOREG_gc;		// unlock Change Protected Registers
	CLKCTRL_MCLKCTRLB = CLKCTRL_PDIV_2X_gc | CLKCTRL_PEN_bm;	// Div x2, set PEN bit to enable.
	// Configure TCA for Normal (default) with clock div x8.
	TCA0_SINGLE_CTRLA = TCA_SINGLE_CLKSEL_DIV8_gc;				// set div x8. Timer disabled.
	// Configure the HC-SR04 interface pins
	HC_DIR |= TRIG;					// set for output.
	HC_PORT &= ~TRIG;				// clear to 0.
	HC_DIR &= ~ECHO;				// set for input.
	// Configure LED pin
	LED_DIR |= LED;					// set for output.
	LED_PORT |= LED;				// turn LED OFF.
	
	// Flash LED three times
	for(int i=0; i<3; i++) {
		LED_PORT &= ~LED;			// turn LED ON.
		_delay_ms(100);
		LED_PORT |= LED;			// turn LED OFF.
		_delay_ms(900);
	}
	
	// Stay in this infinite loop
    while (1) 
    {
		// Generate a 10us pulse on the TRIG line.[1]
		HC_PORT |= TRIG;			// Set Trig HIGH to start the sensor transmission.
		_delay_us(10);				// sets the width of the Trigger pulse.
		HC_PORT &= ~TRIG;			// Set Trig LOW to end the pulse.
		// Wait for the ECHO line to go HIGH to indicate that echo timing has started.[1]
		while( !(HC_PIN & ECHO) );
		// Start the Timer now that the Echo has started.
		TCA0_SINGLE_CTRLA |= TCA_SINGLE_ENABLE_bm;		// Enable Timer.
		// Wait for the ECHO line to go LOW.
		// This will occur at 38ms if no echo has return. (i.e. no object detected)
		while( (HC_PIN & ECHO) );
		// Stop Timer.
		TCA0_SINGLE_CTRLA &= ~TCA_SINGLE_ENABLE_bm;		// Disable Timer.
		// Read the timer count.
		time = TCA0_SINGLE_CNT;							// Read timer count.
		// Reset the timer to 0.
		TCA0_SINGLE_CNT = 0;							// Clear timer count.
		// If the timer count is < 1000 (about 15cm), set LED ON, else set LED OFF.
		if( time < 1000 ) {
			LED_PORT &= ~LED;		// Turn ON
		} else {
			LED_PORT |= LED;		// Turn OFF
		}
		_delay_ms(50);
    }
}

