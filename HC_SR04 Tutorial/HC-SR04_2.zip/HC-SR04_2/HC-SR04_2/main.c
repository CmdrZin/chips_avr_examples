/*
 * The MIT License
 *
 * Copyright 2021 CmdrZin.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sub-license, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * Project: HC-SR04_2
 *
 * Created: 1/7/2021 9:39:34 PM
 * Author : Cmdrzin
 */ 

#include <avr/io.h>			// require for any AVR project.
#include "sysdefs.h"

#include "led.h"
#include "hc_SR04.h"
#include "timer.h"

/*
 * Simple trigger and wait loop.
 */
int main(void)
{
	uint16_t time;

	init_timer();	
	init_led();
	init_hc_SR04();
			
	// Flash LED three times
	for(int i=0; i<3; i++) {
		set_led(true);			// turn LED ON.
		_delay_ms(100);
		set_led(false);			// turn LED OFF.
		_delay_ms(900);
	}
	
	// Stay in this infinite loop
    while (1) 
    {
		// Generate a 10us pulse on the TRIG line.
		trigger_hc_SR04();
		// Measure the Echo time. Blocking call: 5ms to 38ms.
		time = service_hc_SR04();

		// If the timer count is < 1000 (about 15cm), set LED ON, else set LED OFF.
		if( time < 1000 ) {
			set_led(true);		// Turn ON
		} else {
			set_led(false);		// Turn OFF
		}

		// Wait for any secondary echoes to pass.
		_delay_ms(50);
    }
}

