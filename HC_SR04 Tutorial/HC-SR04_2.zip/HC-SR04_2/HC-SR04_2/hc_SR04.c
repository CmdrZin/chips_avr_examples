/*
* The MIT License
*
* Copyright 2021 CmdrZin.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sub-license, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*
* hc_SR04.c
*
* Created: 1/7/2021 9:45:24 PM
* Author : Cmdrzin
*/

#include <avr/io.h>			// require for any AVR project.
#include "sysdefs.h"

// These definitions will differ based on the processor used.
#define HC_DIR		PORTB_DIR	// DDR register.
#define	HC_PORT		PORTB_OUT	// Port for output pin connected to the HC-SR04.
#define TRIG		PIN3_bm		// TRIG input to HC-SR04 sensor.
#define	HC_PIN		PORTB_IN	// Port for input pin connected to the HC-SR04.
#define ECHO		PIN2_bm		// ECHO output of the HC-SR04 sensor.

// Configuration of the hardware for use with the HC-SR04 sensor.
void init_hc_SR04()
{
	// Configure the HC-SR04 interface pins
	HC_DIR |= TRIG;					// set for output.
	HC_PORT &= ~TRIG;				// clear to 0.
	HC_DIR &= ~ECHO;				// set for input.
}

// Trigger the sensor. Blocking: This takes a maximum of 11 us.
void trigger_hc_SR04()
{
	// Generate a 10us pulse on the TRIG line.[1]
	HC_PORT |= TRIG;			// Set Trig HIGH to start the sensor transmission.
	_delay_us(10);				// sets the width of the Trigger pulse.
	HC_PORT &= ~TRIG;			// Set Trig LOW to end the pulse.
}

// Measure the Echo time. Blocking: This takes a maximum of 38 ms.
uint16_t service_hc_SR04()
{
	uint16_t time;
	
	// Wait for the ECHO line to go HIGH to indicate that echo timing has started.[1]
	while( !(HC_PIN & ECHO) );
	// Start the Timer now that the Echo has started.
	TCA0_SINGLE_CTRLA |= TCA_SINGLE_ENABLE_bm;		// Enable Timer.
	// Wait for the ECHO line to go LOW.
	// This will occur at 38ms if no echo has return. (i.e. no object detected)
	while( (HC_PIN & ECHO) );
	// Stop Timer.
	TCA0_SINGLE_CTRLA &= ~TCA_SINGLE_ENABLE_bm;		// Disable Timer.
	// Read the timer count.
	time = TCA0_SINGLE_CNT;							// Read timer count.
	// Reset the timer to 0.
	TCA0_SINGLE_CNT = 0;							// Clear timer count.

	return time;
}