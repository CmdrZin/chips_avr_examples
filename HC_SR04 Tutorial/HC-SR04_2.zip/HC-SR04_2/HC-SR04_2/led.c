/*
* The MIT License
*
* Copyright 2021 CmdrZin.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sub-license, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*
* led.c
*
* Created: 1/7/2021 9:45:52 PM
* Author : Cmdrzin
*/
#include <avr/io.h>			// require for any AVR project.

#include "led.h"

// These definitions will differ based on the processor used.
#define LED_DIR		PORTF_DIR
#define LED_PORT	PORTF_OUT	// I/O Port for output to on-board LED.
#define LED			PIN5_bm		// LED drive pin.

void init_led()
{
	// Configure LED pin
	LED_DIR |= LED;				// set for output.
	set_led(false);				// turn LED OFF.
}

// This logic may change based on how the LED is connected.
void set_led(bool state)
{
	if(state) {
		LED_PORT &= ~LED;			// turn LED ON.
	} else {
		LED_PORT |= LED;			// turn LED OFF.
	}
}