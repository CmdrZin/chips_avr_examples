/*
 * sysdefs.h
 *
 * Created: 1/7/2021 10:14:48 PM
 *  Author: Chip
 */ 


#ifndef SYSDEFS_H_
#define SYSDEFS_H_

#define F_CPU	10000000	// Definition needed for delay.h functions. Needs to be before #include.

#include <util/delay.h>		// needed for _delay_us().



#endif /* SYSDEFS_H_ */