/*
 * File:   systime.c
 * Author: Cmdrzin
 *
 * Created on August 8, 2024, 12:29 PM
 */


#include <avr/io.h>
#include "systime.h"

volatile static uint32_t totalMilliseconds;	// global variable

/* TCB interrupt service routine. */
ISR(TCB0_INT_vect)
{
   	++totalMilliseconds;
    TCB0.INTFLAGS = TCB_CAPT_bm;   // clear the interrupt flag
}

/* Return the total number of milliseconds since the project started. */
uint32_t millis(void)
{
	uint32_t temp;			// make a holder for the counter.

	cli();				// Turn OFF interrupts to avoid corruption
						// during a multi-byte read.
	temp = totalMilliseconds;	// get a copy while interrupts are disabled.
	sei();				// Turn interrupts back ON.

	return temp;			// return a 'clean' copy of the counter.
}

/* *** TCB Configuration as NORMAL counter with interrupt for 1ms OVF *** */
void init_systime(void)
{
    // The CCMP register contains the TOP value of the counter.
	TCB0.CCMP = 0x0D04;       // 3,333 - 1 since the counter starts at 0.
   	/* enable periodic interrupt interrupt */
	TCB0.INTCTRL = TCB_CAPT_bm;
	/* set mode */
//	TCB0.CTRLB = (default mode is periodic interrupt.)
//	TCB0.CTRLA = (default, use CLK_PER 3.333 MHz)
}
