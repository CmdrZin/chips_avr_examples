/* 
 * File:   tcd.h
 * Author: CmdrZin
 *
 * Created on October 16, 2024, 2:59 PM
 */

#ifndef TCD_H
#define	TCD_H

void init_TCD();
void setTCD_setA(uint16_t val);
void setTCD_setB(uint16_t val);

#endif	/* TCD_H */

