/* 
 * File:   sysdefs.h
 * Author: Cmdrzin
 *
 * Created on August 8, 2024, 12:55 PM
 */

#ifndef SYSDEFS_H
#define	SYSDEFS_H

#include <avr/io.h>

#define CCP_IOREG_gc    (CPU_CCP_7_bm | CPU_CCP_6_bm | CPU_CCP_4_bm | CPU_CCP_3_bm)    // 0xD8

#define RTC_CLKSEL_INT32K_gc    (0)
        
#endif	/* SYSDEFS_H */

