/*
 * File:   main.c
 * Author: Cmdrzin
 *
 * Created on August 6, 2024
 * 
 * Target: ATtinyt412 8SOIC
 * 
 * Section III.8 - RTC
 */


#include <avr/io.h>
#include <avr/interrupt.h>          // to support the use of interrupts
#include "sysdefs.h"
#include "systime.h"                // access systime functions.
#include "io_ctrl.h"

#define LED_DELAY		500UL		// N * 1ms

void init_rtc();

int main(void) {
   	uint32_t ledTime = 0UL;

    init_systime();             // set up TCA0 timer.
    init_io();                  // set up IO pins.
    init_rtc();
    
    /* enable Global interrupts */
    sei();
   
    // Read voltage. Set LED based on value.
    while (1) {
		if( millis() > ledTime ) {
			ledTime = millis() + LED_DELAY;
//            toggle_LED();
            
		}
    }
}


// RTC setup
void init_rtc()
{
    CPU_CCP = CCP_IOREG_gc;		// unlock Change Protected IO Registers
    CLKCTRL.OSC32KCTRLA = 0x02; // Force startup of oscillator.
    
    RTC.CLKSEL = RTC_CLKSEL_INT32K_gc;    // 32.768kHz Internal Crystal Oscillator (INT32K)

    while( RTC.STATUS > 0);             // Wait for RTC to synchronize with system.
    
    // Set RTC Period register to overflow at 1024
    RTC.PER = 512;
    // Enable interrupt on overflow.
    RTC.INTCTRL |= RTC_OVF_bm;
    // DIV32
    RTC.CTRLA = RTC_PRESCALER_2_bm | RTC_PRESCALER_0_bm     // 0x05 for DIV32 for 1024 Hz clock.
            | RTC_RTCEN_bm;                                  // Enable the RTC
//            | RTC_RUNSTDBY_bm;                              // Run in standby (Sleep Mode)
    
}

// RTC Interrupt
ISR(RTC_CNT_vect)
{
    RTC.INTFLAGS = RTC_OVF_bm;
    toggle_LED();
}
