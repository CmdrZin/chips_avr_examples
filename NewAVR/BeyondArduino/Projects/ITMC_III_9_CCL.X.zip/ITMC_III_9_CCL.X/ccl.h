/* 
 * File:   ccl.h
 * Author: CmdrZin
 *
 * Created on October 17, 2024, 3:27 PM
 */

#ifndef CCL_H
#define	CCL_H

void init_CCL();

#endif	/* CCL_H */

