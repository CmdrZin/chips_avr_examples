/* 
 * File:   sysdefs.h
 * Author: Cmdrzin
 *
 * Created on August 8, 2024, 12:55 PM
 */

#ifndef SYSDEFS_H
#define	SYSDEFS_H

// Place system defines here.

#endif	/* SYSDEFS_H */

