/* 
 * File:   dac.h
 * Author: Cmdrzin
 *
 * Created on September 3, 2024, 1:46 PM
 */

#ifndef DAC_H
#define	DAC_H

void init_dac();
void set_dac_output(uint8_t value);

#endif	/* DAC_H */

