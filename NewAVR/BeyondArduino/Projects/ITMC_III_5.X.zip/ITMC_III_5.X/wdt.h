/* 
 * File:   wdt.h
 * Author: Cmdrzin
 *
 * Created on September 14, 2024, 4:57 PM
 */

#ifndef WDT_H
#define	WDT_H

void init_wdt(void);
void resetWDT(void);

#endif	/* WDT_H */

