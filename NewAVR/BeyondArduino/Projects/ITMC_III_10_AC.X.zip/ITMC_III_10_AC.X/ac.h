/* 
 * File:   ac.h
 * Author: Cmdrzin
 *
 * Created on October 30, 2024, 4:41 PM
 */

#ifndef AC_H
#define	AC_H

#include <stdbool.h>

void init_ac();
bool check_ac();

#endif	/* AC_H */

