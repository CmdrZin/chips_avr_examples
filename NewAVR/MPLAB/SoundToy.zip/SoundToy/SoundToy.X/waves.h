/* 
 * File:   waves.h
 * Author: Cmdrzin
 *
 * Created on May 26, 2025, 1:46 PM
 */

#ifndef WAVES_H
#define	WAVES_H

#include <avr/pgmspace.h>

extern const PROGMEM char ma_sinTable88[256];
extern const PROGMEM char ma_randomTable112[256];
extern const PROGMEM char ma_squareTable112[256];
extern const PROGMEM char ma_triangleTable112[256];
extern const PROGMEM char ma_rampUpTable112[256];
extern const PROGMEM char ma_rampDnTable112[256];

#endif	/* WAVES_H */

