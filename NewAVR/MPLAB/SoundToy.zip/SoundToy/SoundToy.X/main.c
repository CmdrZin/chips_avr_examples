/*
 * File:   main.c
 * Author: Cmdrzin
 *
 * Created on May 18, 2025, 2:58 PM
 */


#include <avr/io.h>
#include <stdbool.h>

#include "system.h"
#include "rtc.h"
#include "mod_led.h"
#include "ddsDAC.h"

#define HB_WAIT 500

typedef enum {S_OFF, S_NOTES, S_BEDO, S_ALARM_SETUP, S_ALARM,
        S_LASER_SETUP, S_LASER, S_WOOP_SETUP, S_WOOP} SOUND;

uint32_t ledTime = 0;
uint32_t soundTime = 0;
uint32_t delayOneTime = 0;

// Note Table
uint16_t notes[7] = {F_C4, F_D4, F_E4, F_F4, F_G4, F_A4, F_B4, F_C4*2};
uint8_t totalNotes = sizeof(notes)/sizeof(notes[0]);

int main(void) {
    bool hbOn = false;
    bool flip = false;
    uint8_t noteIndex = 0;
    SOUND soundEffect = S_OFF;
    uint8_t chanAmplitude;
    uint16_t noteFreq = 0;

    setSystemClock();

    mod_led_init();
    init_rtc();
    init_dds();
    
    // set DAC Vref to 4.3v.
    VREF.CTRLA |= VREF_DAC0REFSEL_1_bm | VREF_DAC0REFSEL_0_bm;
    PORTA.DIR |= PIN6_bm; // set as OUTPUT
    DAC0.CTRLA |= DAC_OUTEN_bm | DAC_ENABLE_bm;
    
    sei();          // enable global interrupts.
    
    while (1) {
        /* Heartbeat to show that the system is still cycling */
        if(ledTime < millis()) {
            ledTime = millis() + HB_WAIT;
            if(hbOn) {
                hbOn = false;
                mod_led_off();
            } else {
                hbOn = true;
                mod_led_on();
            }
        }

        switch(soundEffect) {
            case S_OFF:
                setChanEnable(0, false);
                setChanEnable(1, false);
                setChanEnable(2, false);
                if(soundTime < millis()) {
                    soundEffect = S_WOOP_SETUP;
                }
                break;
                
            case S_NOTES:
                setChanEnable(0, true);
                if(soundTime < millis()) {
                    soundTime = millis() + HB_WAIT;
                    setTable(0, W_SIN);
                    setInc(0, notes[noteIndex]);
                    if(++noteIndex >= totalNotes) {
                        noteIndex = 0;
                    }
                }
                break;

            // Use Triangle wave to decrease amplitude.
            case S_BEDO:
                setChanEnable(0, true);
                if(soundTime < millis()) {
                    soundTime = millis() + 500;
                    if(flip) {
                        flip = false;
                        setTable(0, W_SIN);
                        setInc(0, notes[2]);
                    } else {
                        flip = true;
                        setTable(0, W_SIN);
                        setInc(0, notes[6]);
                    }
                }
                break;
                
            //Alarm
            case S_ALARM_SETUP:
                setTable(0, W_SIN);
                setInc(0, notes[3]);
                chanAmplitude = 200;
                setChanAmplitude(0, chanAmplitude);
                soundTime = millis() + 1;
                soundEffect = S_ALARM;
                break;
                
            // THIS could be a table driven decay.
            case S_ALARM:
                if(soundTime < millis()) {
                    setChanEnable(0, true);
                    soundTime = millis() + 1;
                    if( (chanAmplitude -= 1) < 10) {
                        soundEffect = S_OFF;
                        soundTime = millis() + 1000;
                        setChanEnable(0, false);
                    }
                    setChanAmplitude(0, chanAmplitude);
                }
                break;

            case S_LASER_SETUP:
                setTable(0, W_SIN);
                setInc(0, notes[4]);
                setTable(1, W_SAWT_DN);
                setInc(1, 2);                   // SLOW
                clearAccumulators();
                chanAmplitude = 255;
                setChanAmplitude(0, chanAmplitude);
                setChanAmplitude(1, chanAmplitude);
                soundTime = millis() + 250;
                soundEffect = S_LASER;
                break;
                
            // THIS could be a table driven decay.
            case S_LASER:
                setChanEnable(0, true);
                setChanEnable(1, true);
                if( soundTime < millis() ) {
                    soundEffect = S_OFF;
                    soundTime = millis() + 2000;
                    setChanEnable(0, false);
                    setChanEnable(1, false);
                }
                break;

            case S_WOOP_SETUP:
                setTable(0, W_SIN);
                noteFreq = 200;
                setInc(0, noteFreq);
                clearAccumulators();
                chanAmplitude = 255;
                setChanAmplitude(0, chanAmplitude);
                soundTime = millis() + 250;
                delayOneTime = millis() + 2;
                soundEffect = S_WOOP;
                break;
                
            // THIS could be a table driven decay.
            case S_WOOP:
                setChanEnable(0, true);
                if( delayOneTime < millis() ){
                    delayOneTime = millis() + 1;
                    noteFreq += 3;
                    setInc(0, noteFreq);
                }
                if( soundTime < millis() ) {
                    soundEffect = S_OFF;
                    soundTime = millis() + 200;         // Repeat Rate.
                    setChanEnable(0, false);
                    setChanEnable(1, false);
                }
                break;

            default:
                break;
        }
    }
}
