/*
 * File:   dds.c
 * Author: Cmdrzin
 *
 * Created on May 18, 2025
 * 
 * Single DDS generator using DAC output.
 * 
 * 
 */


#include <avr/io.h>
#include <avr/pgmspace.h>
#include <stdbool.h>

#include "ddsDAC.h"
#include "waves.h"

uint16_t accumChan[3];
uint16_t incChan[3] = {0, 0, 0};         // 64 -> 256*64
bool enableChan[3] = {false, false, false};
uint8_t amplitude[3] = {255, 0, 0};

uint16_t chanTable[3];
uint16_t waveTables[] = { (uint16_t)ma_sinTable88,
                          (uint16_t)ma_randomTable112,
                          (uint16_t)ma_triangleTable112,
                          (uint16_t)ma_squareTable112,
                          (uint16_t)ma_rampUpTable112,
                          (uint16_t)ma_rampDnTable112
};


void clearAccumulators()
{
    for( int i=0; i<3; i++) {
        accumChan[i] = 0;
    }
}

void setChanAmplitude(uint8_t chan, bool val)
{
    if(chan < 3) {
        amplitude[chan] = val;
    }
}

void setChanEnable(uint8_t chan, bool val)
{
    if(chan < 3) {
        enableChan[chan] = val;
    }
}

// Larger val = higher frequency. 64:256:256*64
void setInc(uint8_t chan, uint16_t val)
{
    if(chan < 3) {
        incChan[chan] = val;
    }
}

void setTable(uint8_t chan, WAVE index)
{
    chanTable[chan] = waveTables[index];
}

/* TCA interrupt service routine. */ 
// This supports Frequency waveform. The waveforms are SUMMED together.
// The result is then MULTIPLED by the envelope value. (see envGen())
// All of this needs to complete within 12us.
ISR(TCA0_OVF_vect)
{
    int i;
    static uint8_t index;
    static uint8_t newDAC;
    uint16_t   tableAdrs;
    
    // Update from last calculations.
    DAC0.DATA = newDAC;

   
    newDAC = 0;
    // Update Channels
    for(i=0;i<3;i++) {
        if(enableChan[i]) {
            accumChan[i] += incChan[i]; // an incChan of 256 creates the base frequency.
            index = accumChan[i]>>8;
            tableAdrs = chanTable[i] + index;
            newDAC += pgm_read_byte( tableAdrs );       // SUM channels
        }
    }
    newDAC += 128;     // shift to center
    
    // Apply envelope
    newDAC = (newDAC * amplitude[0])>>8;
    // Update DAC
    
    TCA0.SINGLE.INTFLAGS = TCA_SINGLE_OVF_bm;   // clear the interrupt flag
}

/* *** TCA Configuration as Single-Slope PWM with interrupt at OVF *** */
void init_dds(void)
{
	TCA0.SINGLE.PER = 0x00FF;       // 8-bit OVF count
   	/* enable overflow interrupt */
	TCA0.SINGLE.INTCTRL = TCA_SINGLE_OVF_bm;
	/* set Single Slope PWM mode (could just use NORMAL) */
	TCA0.SINGLE.CTRLB = TCA_SINGLE_WGMODE_SINGLESLOPE_gc;
	TCA0.SINGLE.CTRLA = TCA_SINGLE_CLKSEL_DIV1_gc  /* set CLK_PER/1 */
					| TCA_SINGLE_ENABLE_bm; 	/* start timer */
    
    // Clear accumulators
    accumChan[0] = 0;
    accumChan[1] = 0;
    accumChan[2] = 0;
    
    setTable(0, W_SIN);
//    setTable(0, W_SQR);
//    setTable(0, W_TRI);
    setTable(1, W_SIN);
    setTable(2, W_SIN);
}
